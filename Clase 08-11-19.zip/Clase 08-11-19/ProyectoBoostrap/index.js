var nums = [1,2,3,4,5,6,7];
let numFilter = [];
// voy a tener un array de la misma cantidad de elementos, pero cada elemento modificado.
nums.map(function(num){
    return num*num;
}) 

// retorna un array con todos los items que cumplan la siguiente condicion, retorna true o false, si es true, ese elemento lo agrega a la lista 
nums.filter(function(num){
    return num>3;
})

//Reduce 
let total = 0; 
//Primer paramentro valor segundo numero de interacion,y el ultimo en que se inicializa 
//Retorna un resultado.
var n= nums.reduce(function(total,num){
 return total+=num;
},0)

var p= nums.reduce(function(total,per){
    if(per.localidad=='avellaneda')
    {
        return total ++;
    }
    else
    {
        return total;
    }
   },0)
//