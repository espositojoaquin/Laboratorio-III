namespace Persona{
    var lista:Array<object> = new Array <object>();
    
    export function Agregar()
    {  
        
       
    }
    
    export function Modificar()
    {
        
    } 
    export function Eliminar()
    {
        
    }
}