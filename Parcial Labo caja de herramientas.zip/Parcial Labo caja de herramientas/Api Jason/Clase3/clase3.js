window.addEventListener("load",inicio);
var filaMod;
var flag=false;
function inicio(){
    divDesaparecer();
    var btnGuardar = document.getElementById("btn2");
    btnGuardar.addEventListener("click",guardar);
    var agregar=document.getElementById("add");
    agregar.addEventListener("click",divAparecer);
    servidor();
}
function sumar(){
    var num1= document.getElementById("num1").value;
    var num2= document.getElementById("num2").value;
    var resultado;
    resultado= parseInt(num1) + parseInt(num2);
    document.getElementById("resultado").value=resultado;

}

function divAparecer()
{
    var diven = document.getElementById("divNom");
    diven.hidden=false;
    
}
function editar(e){
    flag=true;
    e.preventDefault(); 
    var tam= e.target.parentNode.parentNode.children;
    var nombre = e.target.parentNode.parentNode.children[0].innerHTML;
    var apellido = e.target.parentNode.parentNode.children[1].innerHTML;
    document.getElementById("nombre").value=nombre;
    document.getElementById("Apellido").value=apellido;
    divAparecer();
    filaMod=e.target.parentNode.parentNode;
     
}
function modificar(){
    flag=false;
    e.target.parentNode.parentNode.children[0].innerHTML= document.getElementById("nombre").value;
    e.target.parentNode.parentNode.children[1].innerHTML= document.getElementById("Apellido").value;
    divDesaparecer();
}
function hacerColumnas(obj)
{  var tCuerpo = document.getElementById("tabla");
   var objeto = JSON.parse(obj);  
   var colums = Object.keys(objeto); 
    for (var h = 0; h < colums.length; h++) {
    var th = document.createElement("th");
    var text = document.createTextNode(colums[h]);
    th.appendChild(text);
    tCuerpo.appendChild(th);
   }

}

function hacerFilas(objeto){
    var tCuerpo = document.getElementById("body");
  //  var objeto = JSON.parse(obj);    
    var colums = Object.keys(objeto); 
    var row = document.createElement("tr");
    for(var j=0; j<colums.length; j++)
    {
           var cel = document.createElement("td");
           var text = document.createTextNode(objeto[colums[j]]);
           cel.appendChild(text);
           row.appendChild(cel);
           row.addEventListener('dblclick',function(){editar(event)});
    }

    var cel = document.createElement("td");
    var link = document.createElement("a");
    link.setAttribute("href","#");
     link.addEventListener("click",borrar);
    var text = document.createTextNode("Borrar");
    link.appendChild(text);
    cel.appendChild(link);
    row.appendChild(cel);

    tCuerpo.appendChild(row);
    //limpiar();
}
function guardar()
{  // sumar();
   var bandera=seterClases();
   if(flag==true)
   {
       modificar();
   }
   else
   {
       if(bandera==true)
       {
           var fila = document.getElementById("body").innerHTML +="<tr><td>"+document.getElementById("nombre").value + "</td><td>" + document.getElementById("Apellido").value +"</td><td>"+document.getElementById("fecha").value +"</td><td>"+ document.getElementById("telefono").value +"</td>"+ ' <td><a href="" onclick= "borrar(event)"> Borrar </a></td>'+'  <td style="margin:5px"><a href="" onclick= "editar(event)"> Editar </a></td>';
           divDesaparecer();
           agregar();
         //  servidor();
    
       }else
       {
           alert("Complete los datos faltantes");
       }

   }
}
// Funcion que reemplaza el document.getElementById() 
function divDesaparecer(){
    var diven = document.getElementById("divNom");
    diven.hidden=true;

}
function $(id)
{
    var num= document.getElementById(id);
    return num;
}
function borrar(e)
{
    e.preventDefault();
    console.log(e.target);
    console.log(e.target.parentNode);
    console.log(e);
    e.target.parentNode.parentNode.innerHTML="";
    alert("se borro una persona");
}
function seterClases()
{   
    var retorno=true;
    var nombre=document.getElementById("nombre").value;
    var apellido=document.getElementById("Apellido").value;
    if(nombre==""&&apellido=="")
    {
        document.getElementById("nombre").className="error";
        document.getElementById("Apellido").className="error";
        retorno=false;
    }
    else
    {
        document.getElementById("nombre").className="sinError";
        document.getElementById("Apellido").className="sinError";
        retorno=true;
    } 

 return retorno;

}
function servidor()
{ var xml=new XMLHttpRequest();
 // var obj;
  xml.open("GET","http://localhost:3000/personas",true);
  xml.onreadystatechange=function(){
      if(xml.readyState===4)
      {
          if(xml.status===200){
              var s = xml.responseText; // me responde string 
              var lista = JSON.parse(s);
             for (var index = 0; index < lista.length; index++) {
               
                hacerFilas(lista[index]);
               // var fila = document.getElementById("body").innerHTML +="<tr><td>"+ lista[index].nombre + "</td><td>" + lista[index].apellido+"</td><td>"+lista[index].fecha +"</td><td>"+ lista[index].telefono +"</td>"+ ' <td><a href="" onclick= "borrar(event)"> Borrar </a></td>'+'  <td style="margin:5px"><a href="" onclick= "editar(event)"> Editar </a></td>';
              //  divDesaparecer();
               //  obj = lista[index];
             }
            // return obj;
          }
      }
  }
  xml.send();
}
function agregar(){
  var xml=new XMLHttpRequest();
  //var theUrl = "/json-handler";
  var obj = {"nombre":document.getElementById("nombre").value,"apellido":document.getElementById("Apellido").value,"fecha":document.getElementById("fecha").value,"telefono":document.getElementById("telefono").value};
  xml.open("POST","http://localhost:3000/nuevaPersona",true);
  xml.setRequestHeader("Content-Type","application/JSON");
  xml.onreadystatechange=function(){
      if(xml.readyState===4)
      {
          if(xml.status===200){
              
          }
      }
  }
  xml.send(JSON.stringify(obj)); /// en post se pasan paramentros por send y url en get. 
}