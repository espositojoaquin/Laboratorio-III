var persona='{"nombre":"joa",edad:31}'; //objeto jason en string 

JSON.stringify(persona);// convierte un objeto en tipo json string 
JSON.parse(persona) // convierte de un tipo string a json. 
persona.edad;
persona.nombre;
persona["nombre"]; // se puede acceder tambien asi
persona["edad"];

var lista=[]; //esto es un array vacio


var elemento =document.createElement("p");
// para agregar texto en el medio 
var texto= document.createTextNode("Hola Mundo");
elemento.appendChild(texto); // se le agrega un hijo que seria el texto que esta entre medio

var body= document.getElementById("body");
body.appendChild(elemento);
