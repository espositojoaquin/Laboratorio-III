var nombre;
nombre = "joa";
nombre = 1231
// crear una funcion que genere los elemnetos del div y otro que cargue los elementos. 

function sumar(num1, num2) {

    alert(num1 + num2);
    return num1 + num2;
}

/*function mostrar() {
    var http= new XMLHttpRequest();
    var user = document.getElementById("user").value;
    var password = document.getElementById("contra").value;
    http.onreadystatechange = function(){
        console.log("Llego respuesta",http.readyState,http.status);
        if(http.readyState===4){
            
            if(http.status===200){
             console.log("tenemos Respuesta",http.responseText);
            }
        }
    } */

    function Enviar(){
        var xml=new XMLHttpRequest();
        //var theUrl = "/json-handler";
     //   var obj = {"nombre":document.getElementById("nombre").value,"apellido":document.getElementById("Apellido").value,"fecha":document.getElementById("fecha").value,"telefono":document.getElementById("telefono").value};
        var datosLogin ={
            email: document.getElementById("user").value,
            password:document.getElementById("contra").value
        }
        xml.open("POST","http://localhost:1337/login",true);
       // xml.setRequestHeader("Content-Type","application/JSON"); no se lo pasamos porque en este servidor pincha
        xml.onreadystatechange=function(){
            if(xml.readyState===4)
            {
                if(xml.status===200){
                    console.log("tenemos Respuesta",xml.responseText);
                    var a = JSON.parse(xml.responseText) 
                    if(a.autenticado=="si")
                    {
                       // window.location.replace("./Trabajo.html?color="+a.preferencias.color+"&font="+ a.preferencias.font +"&email="+datosLogin.password);
                       window.location.replace("./Trabajo.html");
                    }
                }
            }
        }
        xml.send(JSON.stringify(datosLogin)); /// en post se pasan paramentros por send y url en get. 
      }



   

//console.log(sumar(1, 2));