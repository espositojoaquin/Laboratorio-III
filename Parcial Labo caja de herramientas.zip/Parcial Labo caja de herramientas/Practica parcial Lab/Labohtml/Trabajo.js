window.addEventListener("load",inicio);

var flagForm=false;
var flagcolum=false;
var filaMod;
function divAparecer(){
    var diven = document.getElementById("formulario");
    diven.hidden=false;

}
function spinerAparecer(){
    var diven = document.getElementById("imgSpiner");
    diven.hidden=false;
}
function spinerDesaparecer(){
    var diven = document.getElementById("imgSpiner");
    diven.hidden=true;
}
function divDesaparecer(){
    var diven = document.getElementById("formulario");
    diven.hidden=true;
    flagForm=true;
}
function limpiar(){
    document.getElementById("Titleid").value="";
    document.getElementById("Headerid").value="";
    document.getElementById("Textid").value=""; 
}
var datos=[{
    nombre:"joa",
    email: "joa@hotmail.com",
    sexo: "masculino",
    Cuadro:"independiente",
    Socio: "1565"
},
{
nombre:"Pau",
email: "joa@hotmail.com",
sexo: "Femenimo",
Cuadro: "Independiente",
Socio: "1478"
}]
function inicio(){
    //divDesaparecer();
    var btnGuardar = document.getElementById("new");
    btnGuardar.addEventListener("click",HacerForm);
    
  //  hacerTabla(JSON.stringify(datos));
}
function HacerForm()
{   
    
    var diven = document.getElementById("formulario");
    if(diven.hidden==true && flagForm==false)
    {
        var div = document.getElementById("formulario");
        var h3 = document.createElement("h3");
        var textoH3= document.createTextNode("Write your New Post");
        h3.appendChild(textoH3);
        div.appendChild(h3);
        var label = document.createElement("label");
        var textoLabel1 = document.createTextNode("Post Title");
        label.appendChild(textoLabel1);
        div.appendChild(label);
        var input= document.createElement("input");
        input.type="text";
        input.id="Titleid";
        div.appendChild(input);
        var label2 = document.createElement("label");
        var textoLabel2 = document.createTextNode("Post Header");
        label2.appendChild(textoLabel2);
        div.appendChild(label2);
        var input2= document.createElement("input");
        input2.type="text";
        input2.id="Headerid";
        div.appendChild(input2);
        var label3 = document.createElement("label");
        var textoLabel3 = document.createTextNode("Post Text");
        label3.appendChild(textoLabel3);
        div.appendChild(label3);
        var input3= document.createElement("input");
        input3.type="text";
        input3.id="Textid";
        div.appendChild(input3);
        var label4 = document.createElement("label");
        var textoLabel4 = document.createTextNode("Radio");
        label4.appendChild(textoLabel4);
        div.appendChild(label4);
        var salto = document.createElement("br");
        div.appendChild(salto);
        var input4 = document.createElement("input");
        //<input type="radio" name="gender" value="male"> Male<br>
        input4.type="radio";
        input4.value="opcion1";
        input4.name="gender";
        input4.id="Radioid";
        div.appendChild(input4);
        var radio1= document.createElement("label");
        var textoRadio = document.createTextNode("Opcion 1");
        radio1.appendChild(textoRadio);
        div.appendChild(radio1);
        var salto2 = document.createElement("br");
        div.appendChild(salto2);
        var input5 = document.createElement("input");
        input5.type="radio";
        input5.value="opcion2";
        input5.name="gender";
        input5.id="Radio2id";
        div.appendChild(input5);
        var radio2= document.createElement("label");
        var textoRadio = document.createTextNode("Opcion 2");
        radio2.appendChild(textoRadio);
        div.appendChild(radio2);
        var salto3 = document.createElement("br");
        div.appendChild(salto3);
        var botonPost= document.createElement("input");
        botonPost.value="Post";
        botonPost.id="postId";
        botonPost.type="button";
        botonPost.addEventListener('click',Enviar);
        var botonModificar= document.createElement("input");
        botonModificar.value ="Modificar";
        botonModificar.id="btnModificar";
        botonModificar.type="button";
        botonModificar.className="boton";
        botonModificar.addEventListener("click",function(){modificar(event)})

        div.appendChild(botonModificar);
        div.appendChild(botonPost);
    }
    divAparecer();
}
function borrar(e){
    e.preventDefault(); 
   
    e.target.parentNode.parentNode.innerHTML="";
 
}
function editar(e){
   
    e.preventDefault(); 
   
    //var tam= e.target.parentNode.parentNode.children;
    var title = e.target.parentNode.children[0].innerHTML;
    var header = e.target.parentNode.children[1].innerHTML;
    var text =  e.target.parentNode.children[2].innerHTML
    document.getElementById("Titleid").value= title;
    document.getElementById("Headerid").value=header;
    document.getElementById("Textid").value=text;
    divAparecer();
    filaMod=e.target.parentNode;
}
function modificar(){
 
    filaMod.children[0].innerHTML =  document.getElementById("Titleid").value;
    filaMod.children[1].innerHTML =  document.getElementById("Headerid").value;
    filaMod.children[2].innerHTML =  document.getElementById("Textid").value;
    divDesaparecer();
    limpiar();
}

function hacerColumnas(obj)
{  var tCuerpo = document.getElementById("tabla");
   var objeto = JSON.parse(obj);  
   var colums = Object.keys(objeto); 
   for (var h = 0; h < colums.length; h++) {
    var th = document.createElement("th");
    var text = document.createTextNode(colums[h]);
    th.appendChild(text);
    tCuerpo.appendChild(th);
   }

}

function hacerFilas(obj){
    var tCuerpo = document.getElementById("tabla");
    var objeto = JSON.parse(obj);    
    var colums = Object.keys(objeto); 
    var row = document.createElement("tr");
    for(var j=0; j<colums.length; j++)
    {
           var cel = document.createElement("td");
           var text = document.createTextNode(objeto[colums[j]]);
           cel.appendChild(text);
           row.appendChild(cel);
           row.addEventListener('dblclick',function(){editar(event)});
    }

    var cel = document.createElement("td");
    var link = document.createElement("a");
    link.setAttribute("href","#");
     link.addEventListener("click",borrar);
    var text = document.createTextNode("Borrar");
    link.appendChild(text);
    cel.appendChild(link);
    row.appendChild(cel);

    tCuerpo.appendChild(row);
    limpiar();
}
//var lista={datos,date};

function hacerTabla(obj)
{
    var tCuerpo = document.getElementById("tabla");
    var objeto = JSON.parse([obj]);    
    for (var i = 0; i <objeto.length; i++) {  
      
        if(i==0)
        {
          hacerColumnas(objeto[i]);
        }

        hacerFilas(objeto[i]);
    
    }
}
function Enviar(){
    var xml=new XMLHttpRequest();
    //var theUrl = "/json-handler";
   divDesaparecer();
   spinerAparecer();
    var datosPost ={
        "title": document.getElementById("Titleid").value,
        "header": document.getElementById("Headerid").value,
        "posttext": document.getElementById("Textid").value,
        "author":"joaquin"
    }
    xml.open("POST","http://localhost:1337/postearNuevaEntrada",true);
   // xml.setRequestHeader("Content-Type","application/JSON"); no se lo pasamos porque en este servidor pincha
    xml.onreadystatechange=function(){
        if(xml.readyState===4)
        {
            if(xml.status===200){
              
               spinerDesaparecer();
                console.log("tenemos Respuesta",xml.responseText);
             //   var a = JSON.parse(xml.responseText) 
               // hacerTabla(xml.responseText); 
             
               if(flagcolum==false)
               {
                   hacerColumnas(xml.responseText);      
               }
               hacerFilas(xml.responseText); 
               flagcolum=true;       
            }
        }
    }
    xml.send(JSON.stringify(datosPost)); /// en post se pasan paramentros por send y url en get. 
  }


