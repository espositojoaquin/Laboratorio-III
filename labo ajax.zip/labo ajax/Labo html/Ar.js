var nombre;
nombre = "joa";
nombre = 1231
/*if (nombre === "1231") {
    alert("El nombre es:1231");

} else {
    alert("No es igual");
}*/

function sumar(num1, num2) {

    alert(num1 + num2);
    return num1 + num2;
}

function mostrar() {
    var http= new XMLHttpRequest();
    var user = document.getElementById("user").value;
    var password = document.getElementById("contra").value;
    http.onreadystatechange = function(){
        console.log("Llego respuesta",http.readyState,http.status);
        if(http.readyState===4){
            
            if(http.status===200){
             console.log("tenemos Respuesta",http.responseText);
            }
        }
    }
   /* http.open("GET","http://localhost:3000/loginUsuario?usr="+user+"&pass="+password);
    http.send();*/
    http.open("POST","http://localhost:3000/loginUsuario",true);
    http.setRequestHeader("Content-type","application/x-www-form-urlencoded");
    http.send("usr="+user+"&pass="+password);


   
}
console.log(sumar(1, 2));