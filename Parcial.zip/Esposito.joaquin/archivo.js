
window.addEventListener("load",inicio);
var filaMod;
var filaElim;
function inicio(){
 
    servidor();
}
function divAparecer()
{
    var diven = document.getElementById("formulario");
    diven.hidden=false;
    
}
function divDesaparecer()
{
    var diven = document.getElementById("formulario");
    diven.hidden=true;
    
}
function editar(e)
{    
    HacerPopUp();
    e.preventDefault(); 
   
   
    var nombre = e.target.children[1].innerHTML;
    var apellido = e.target.children[2].innerHTML;
    var sexo =  e.target.children[3].innerHTML;
    document.getElementById("nombreId").value= nombre;
    document.getElementById("apellidoId").value= apellido;
    if(sexo=="Female"){
        document.getElementById("Radioid").checked = true;
    }else
    {
        document.getElementById("Radio2id").checked =true;
    }
    //document.getElementById("Textid").value=text;
    divAparecer();
    filaMod=e.target;
    filaElim=e;
    
}
function modificar(){
 
    filaMod.children[1].innerHTML =  document.getElementById("nombreId").value;
    filaMod.children[2].innerHTML =  document.getElementById("apellidoId").value;
    if( document.getElementById("Radioid").value == "Femenino")
    {
        filaMod.children[3].innerHTML = "Female";
        
    }
    else
    {
        filaMod.children[3].innerHTML = "Male";
    }
    divDesaparecer();
   // limpiar();
}
function HacerForm(obj)
{   
        var div = document.getElementById("contenedor");
        
        var tarj = document.createElement("div");
          
       

        tarj.className="tarjetas";
        tarj.addEventListener("dblclick",editar)
        var img = document.createElement("img");
        img.className="imgUs";
        img.src="./user.png";
        tarj.appendChild(img);

        var labelNom = document.createElement("lable");
        var textNom = document.createTextNode(obj.nombre);
        labelNom.appendChild(textNom);
        tarj.appendChild(labelNom);

        var labelApe = document.createElement("lable");
        var textApe = document.createTextNode(obj.apellido);
        labelApe.appendChild(textApe);
        tarj.appendChild(labelApe);

        var labelSex = document.createElement("lable");
        var textSex = document.createTextNode(obj.sexo);
        labelSex.appendChild(textSex);

        tarj.appendChild(labelSex); 
        var labelid = document.createElement("lable");
        var textId = document.createTextNode(obj.id);
        labelid.appendChild(textId);

        tarj.appendChild(labelid); 

        div.appendChild(tarj);
         
   
}
function eliminar()
{
 filaMod="";
}

function HacerPopUp()
{   
    var diven = document.getElementById("formulario");
    if(diven.hidden==true)
    {
        var div = document.getElementById("formulario");
       
        var label = document.createElement("label");
        var textoLabel1 = document.createTextNode("Nombre");
        label.appendChild(textoLabel1);
        div.appendChild(label);
        var input= document.createElement("input");
        input.type="text";
        input.id="nombreId";
        div.appendChild(input);
        var label2 = document.createElement("label");
        var textoLabel2 = document.createTextNode("Apellido");
        label2.appendChild(textoLabel2);
        div.appendChild(label2);
        var input2= document.createElement("input");
        input2.type="text";
        input2.id="apellidoId";
        div.appendChild(input2);

        var label4 = document.createElement("label");
        var textoLabel4 = document.createTextNode("Sexo");
        label4.appendChild(textoLabel4);
        div.appendChild(label4);
        var salto = document.createElement("br");
        div.appendChild(salto);
        var input4 = document.createElement("input");
        //<input type="radio" name="gender" value="male"> Male<br>
        input4.type="radio";
        input4.value="Femenino";
        input4.name="gender";
        input4.id="Radioid";
        div.appendChild(input4);
        var radio1= document.createElement("label");
        var textoRadio = document.createTextNode("Femenino");
        radio1.appendChild(textoRadio);
        div.appendChild(radio1);
        var salto2 = document.createElement("br");
        div.appendChild(salto2);
        var input5 = document.createElement("input");
        input5.type="radio";
        input5.value="Masculino";
        input5.name="gender";
        input5.id="Radio2id";
        div.appendChild(input5);
        var radio2= document.createElement("label");
        var textoRadio = document.createTextNode("Masculino");
        radio2.appendChild(textoRadio);
        div.appendChild(radio2);
        var salto3 = document.createElement("br");
        div.appendChild(salto3);
        var botonEliminar= document.createElement("input");
        botonEliminar.value="Eliminar";
        botonEliminar.id="postId";
        botonEliminar.type="button";
        botonEliminar.addEventListener('click',eliminar);
        var botonModificar= document.createElement("input");
        botonModificar.value ="Modificar";
        botonModificar.id="btnModificar";
        botonModificar.type="button";
        botonModificar.className="boton";
        botonModificar.addEventListener("click",modificar)

        div.appendChild(botonModificar);
        div.appendChild(botonEliminar);
    }
    //divAparecer();
}
/*function Enviar(){
    var xml=new XMLHttpRequest();
    //var theUrl = "/json-handler";
   divDesaparecer();
   spinerAparecer();
   if(document.getElementById("RadioId").checked){
       sexo="Female";
   }
   else
   {
       sexo="Male";
   }
   var sexo;

    var datosPost ={
        "nombre": document.getElementById("nombreId").value,
        "apellido": document.getElementById("apellidoId").value,
        "posttext": sexo,
       // "id": 
    }
    xml.open("POST","http://localhost:3000/editar",true);
   // xml.setRequestHeader("Content-Type","application/JSON"); no se lo pasamos porque en este servidor pincha
    xml.onreadystatechange=function(){
        if(xml.readyState===4)
        {
            if(xml.status===200){
              
               spinerDesaparecer();
                console.log("tenemos Respuesta",xml.responseText);
             //   var a = JSON.parse(xml.responseText) 
               // hacerTabla(xml.responseText); 
             
               if(flagcolum==false)
               {
                   hacerColumnas(xml.responseText);      
               }
               hacerFilas(xml.responseText); 
               flagcolum=true;       
            }
        }
    }
    xml.send(JSON.stringify(datosPost)); /// en post se pasan paramentros por send y url en get. 
  }*/
function servidor()
{ var xml=new XMLHttpRequest();
 // var obj;
  xml.open("GET","http://localhost:3000/personas",true);
  xml.onreadystatechange=function(){
      if(xml.readyState===4)
      {
          if(xml.status===200){
              var s = xml.responseText; // me responde string 
              var lista = JSON.parse(s);
             for (var index = 0; index < lista.length; index++) {
                  
                console.log(lista[index]);
                HacerForm(lista[index]);
                
             }
            // return obj;
          }
      }
  }
  xml.send();
}