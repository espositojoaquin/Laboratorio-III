namespace vehiculos
{
   export  class  Auto extends Vehiculo{   // si animal fuera una clase lo puedo heredar asi
        puertas:number; 

        public constructor(id:number,marc:string,mod:string,pre:number,puerta:number)
        { super(id,marc,mod,pre); 
            
            this.puertas = puerta;
        } 
        public getMarc():string{
            return this.marca;
        }
        public getMod():string{
            return this.modelo;
        }
        public getPre():number{
            return this.precio;
        }
        public getPuer():number{
            return this.puertas;
        }
        public getId():number{
            return this.id;
        }
        


    } 
  
}