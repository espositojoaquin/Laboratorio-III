namespace vehiculos
{
    export  class  Camioneta extends Vehiculo{   // si animal fuera una clase lo puedo heredar asi
        
        cuatroXcuatro:string; 
      
        public constructor(id:number,marc:string,mod:string,pre:number,cua:string)
        { super(id,marc,mod,pre); 
            
            this.cuatroXcuatro = cua;
        } 
        public getMarc():string{
            return this.marca;
        }
        public getMod():string{
            return this.modelo;
        }
        public getPre():number{
            return this.precio;
        }
        public getCua():string{
            return this.cuatroXcuatro;
        }
        public getId():number{
            return this.id;
        }
        


    } 

}