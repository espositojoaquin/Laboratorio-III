
namespace vehiculos{
  
    $("document").ready(function(){
        
      $("#btnAlta").click(Agregar);
      $("#Cancelar").click(Prom);
        
    })
    var lista:Array<Vehiculo> = new Array();
    var flag=false;
    export function Agregar()
    { 
           
            let marca:string = String($("#marca").val());
            let modelo:string = String($("#modelo").val());
            let precio:number = Number($("#precio").val());
            let puertas:number = Number($("#puertas").val());
            let cuatro:string =  String($("cuatro").val());
            let vehi;
            if( $("cuatro").val() == "NoCorresponde")
            {
                vehi = new Auto(BuscarIDMasAlto()+1,marca,modelo,precio,puertas);
                
            }
            else
            {
               vehi =  new Camioneta(BuscarIDMasAlto()+1,marca,modelo,precio,cuatro);
            }
            lista.push(vehi);  
            llenarGrilla2(lista);
           /* $('html,body').animate({
              scrollTop: $("#tabla").offset().top
          }, 500);*/
        
       
    } 
    export function BuscarIDMasAlto():number{
       
         let IDMasAlto: number = lista.reduce(function (IDMasAlto, vehiculo) {
            if(vehiculo as Auto)
            {  let aux = <Auto>vehiculo;
                if(aux.getId() > IDMasAlto){
                    IDMasAlto = aux.getId();
                }

            }
            else
            {
                let aux = <Camioneta>vehiculo;
                if(aux.getId() > IDMasAlto){
                    IDMasAlto = aux.getId();
                }
            }
            return IDMasAlto;
        },0);

        return IDMasAlto;
    } 
    
    export function llenarGrilla2(arrayClientes: Array<Vehiculo>)
    {     
        $("#tabla").empty();
         
             let th = document.createElement("th");
             let textTh = document.createTextNode("Id");
             th.appendChild(textTh);
             $("#tabla").append(th);
        
             let thn = document.createElement("th");
             let textN = document.createTextNode("Marca")
             thn.appendChild(textN);
             $("#tabla").append(thn);
         
     
             let thA = document.createElement("th");
             let textA = document.createTextNode("Modelo")
             thA.appendChild(textA);
             $("#tabla").append(thA);
         
         
             let thE = document.createElement("th");
             let textE = document.createTextNode("Precio")
             thE.appendChild(textE);
             $("#tabla").append(thE);
         
         
             let thS = document.createElement("th");
             let textS = document.createTextNode("Cantidad de Puertas")
             thS.appendChild(textS);
             $("#tabla").append(thS);
          
         let Ac = document.createElement("th");
             let textAc = document.createTextNode("CuatroXCuatro")
             Ac.appendChild(textAc);
             $("#tabla").append(Ac);
        
      
         

        arrayClientes.forEach(function(per){
        let tr = document.createElement("tr");
            
                 let tdC = document.createElement("td");
                 let textC = document.createTextNode(per.id.toString());
                 tdC.appendChild(textC);
                 tr.appendChild(tdC);
             
             
            
                 let tdNom = document.createElement("td");
                 let textNom = document.createTextNode(per.marca);
                 tdNom.appendChild(textNom);
                 tr.appendChild(tdNom);
                

             
             
                 let tdApe = document.createElement("td");
                 let textApe = document.createTextNode(per.modelo);
                 tdApe.appendChild(textApe);
                 tr.appendChild(tdApe);

             
             
                 let tdEdad = document.createElement("td");
                 let textEdad = document.createTextNode(per.precio.toString());
                 tdEdad.appendChild(textEdad);
                 tr.appendChild(tdEdad);

                
                 if(per as Auto)
                 {   
                     let aux:Auto = <Auto>per
                     let tdSex = document.createElement("td");
                   //  let textSex = document.createTextNode((<Auto>per).getPuer().toString());
                     let textSex = document.createTextNode("");

                     tdSex.appendChild(textSex);
                     tr.appendChild(tdSex);
                 }
                 else
                 {
                    let tdSex = document.createElement("td");
                    let textSex = document.createTextNode("");
                    tdSex.appendChild(textSex);
                    tr.appendChild(tdSex);
                 }
                 if(per as Camioneta)
                 {
                     let aux:Camioneta = <Camioneta>per
                     let tdSex = document.createElement("td");
                     let textSex = document.createTextNode(aux.getCua());
                     tdSex.appendChild(textSex);
                     tr.appendChild(tdSex);

                 }
                 else
                 {
                    let tdSex = document.createElement("td");
                    let textSex = document.createTextNode("");
                    tdSex.appendChild(textSex);
                    tr.appendChild(tdSex);
                 }

        
            $("#tabla").append(tr);
        })     
    } 

    export function Promedio()
    {
      let  valor = lista.reduce(function(sumador, item){
            return sumador + item.precio;
        },0) / lista.length;
        
        $("#Prom").val(valor);
       console.log(valor);
       return valor;
          
    } 

    export function Prom()
    {
        alert(Promedio());
    } 

    export function FiltrarMarca(){
        let filtro: String = String($("#txtFiltroNombre").val());
        let arrayFiltrado: Array<Vehiculo> = lista.filter(function (Cliente:Vehiculo ) {
            if (Cliente.getMarc().match("^" + filtro + "[a-zA-Z\s]*")) {
                return true;
            }
            return false;
        });
        llenarGrilla2(arrayFiltrado);
    }




}