var vehiculos;
(function (vehiculos) {
    $("document").ready(function () {
        $("#btnAlta").click(Agregar);
        $("#Cancelar").click(Prom);
    });
    var lista = new Array();
    var flag = false;
    function Agregar() {
        var marca = String($("#marca").val());
        var modelo = String($("#modelo").val());
        var precio = Number($("#precio").val());
        var puertas = Number($("#puertas").val());
        var cuatro = String($("cuatro").val());
        var vehi;
        if ($("cuatro").val() == "NoCorresponde") {
            vehi = new vehiculos.Auto(BuscarIDMasAlto() + 1, marca, modelo, precio, puertas);
        }
        else {
            vehi = new vehiculos.Camioneta(BuscarIDMasAlto() + 1, marca, modelo, precio, cuatro);
        }
        lista.push(vehi);
        llenarGrilla2(lista);
        /* $('html,body').animate({
           scrollTop: $("#tabla").offset().top
       }, 500);*/
    }
    vehiculos.Agregar = Agregar;
    function BuscarIDMasAlto() {
        var IDMasAlto = lista.reduce(function (IDMasAlto, vehiculo) {
            if (vehiculo) {
                var aux = vehiculo;
                if (aux.getId() > IDMasAlto) {
                    IDMasAlto = aux.getId();
                }
            }
            else {
                var aux = vehiculo;
                if (aux.getId() > IDMasAlto) {
                    IDMasAlto = aux.getId();
                }
            }
            return IDMasAlto;
        }, 0);
        return IDMasAlto;
    }
    vehiculos.BuscarIDMasAlto = BuscarIDMasAlto;
    function llenarGrilla2(arrayClientes) {
        $("#tabla").empty();
        var th = document.createElement("th");
        var textTh = document.createTextNode("Id");
        th.appendChild(textTh);
        $("#tabla").append(th);
        var thn = document.createElement("th");
        var textN = document.createTextNode("Marca");
        thn.appendChild(textN);
        $("#tabla").append(thn);
        var thA = document.createElement("th");
        var textA = document.createTextNode("Modelo");
        thA.appendChild(textA);
        $("#tabla").append(thA);
        var thE = document.createElement("th");
        var textE = document.createTextNode("Precio");
        thE.appendChild(textE);
        $("#tabla").append(thE);
        var thS = document.createElement("th");
        var textS = document.createTextNode("Cantidad de Puertas");
        thS.appendChild(textS);
        $("#tabla").append(thS);
        var Ac = document.createElement("th");
        var textAc = document.createTextNode("CuatroXCuatro");
        Ac.appendChild(textAc);
        $("#tabla").append(Ac);
        arrayClientes.forEach(function (per) {
            var tr = document.createElement("tr");
            var tdC = document.createElement("td");
            var textC = document.createTextNode(per.id.toString());
            tdC.appendChild(textC);
            tr.appendChild(tdC);
            var tdNom = document.createElement("td");
            var textNom = document.createTextNode(per.marca);
            tdNom.appendChild(textNom);
            tr.appendChild(tdNom);
            var tdApe = document.createElement("td");
            var textApe = document.createTextNode(per.modelo);
            tdApe.appendChild(textApe);
            tr.appendChild(tdApe);
            var tdEdad = document.createElement("td");
            var textEdad = document.createTextNode(per.precio.toString());
            tdEdad.appendChild(textEdad);
            tr.appendChild(tdEdad);
            if (per) {
                var aux = per;
                var tdSex = document.createElement("td");
                //  let textSex = document.createTextNode((<Auto>per).getPuer().toString());
                var textSex = document.createTextNode("");
                tdSex.appendChild(textSex);
                tr.appendChild(tdSex);
            }
            else {
                var tdSex = document.createElement("td");
                var textSex = document.createTextNode("");
                tdSex.appendChild(textSex);
                tr.appendChild(tdSex);
            }
            if (per) {
                var aux = per;
                var tdSex = document.createElement("td");
                var textSex = document.createTextNode(aux.getCua());
                tdSex.appendChild(textSex);
                tr.appendChild(tdSex);
            }
            else {
                var tdSex = document.createElement("td");
                var textSex = document.createTextNode("");
                tdSex.appendChild(textSex);
                tr.appendChild(tdSex);
            }
            $("#tabla").append(tr);
        });
    }
    vehiculos.llenarGrilla2 = llenarGrilla2;
    function Promedio() {
        var valor = lista.reduce(function (sumador, item) {
            return sumador + item.precio;
        }, 0) / lista.length;
        $("#Prom").val(valor);
        console.log(valor);
        return valor;
    }
    vehiculos.Promedio = Promedio;
    function Prom() {
        alert(Promedio());
    }
    vehiculos.Prom = Prom;
    function FiltrarMarca() {
        var filtro = String($("#txtFiltroNombre").val());
        var arrayFiltrado = lista.filter(function (Cliente) {
            if (Cliente.getMarc().match("^" + filtro + "[a-zA-Z\s]*")) {
                return true;
            }
            return false;
        });
        llenarGrilla2(arrayFiltrado);
    }
    vehiculos.FiltrarMarca = FiltrarMarca;
})(vehiculos || (vehiculos = {}));
