var vehiculos;
(function (vehiculos) {
    var Vehiculo = /** @class */ (function () {
        function Vehiculo(id, marc, mod, pre) {
            this.id = id;
            this.marca = marc;
            this.modelo = mod;
            this.precio = pre;
        }
        Vehiculo.prototype.getMarc = function () {
            return this.marca;
        };
        return Vehiculo;
    }());
    vehiculos.Vehiculo = Vehiculo;
})(vehiculos || (vehiculos = {}));
