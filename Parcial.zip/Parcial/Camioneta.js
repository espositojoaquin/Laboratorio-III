var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var vehiculos;
(function (vehiculos) {
    var Camioneta = /** @class */ (function (_super) {
        __extends(Camioneta, _super);
        function Camioneta(id, marc, mod, pre, cua) {
            var _this = _super.call(this, id, marc, mod, pre) || this;
            _this.cuatroXcuatro = cua;
            return _this;
        }
        Camioneta.prototype.getMarc = function () {
            return this.marca;
        };
        Camioneta.prototype.getMod = function () {
            return this.modelo;
        };
        Camioneta.prototype.getPre = function () {
            return this.precio;
        };
        Camioneta.prototype.getCua = function () {
            return this.cuatroXcuatro;
        };
        Camioneta.prototype.getId = function () {
            return this.id;
        };
        return Camioneta;
    }(vehiculos.Vehiculo));
    vehiculos.Camioneta = Camioneta;
})(vehiculos || (vehiculos = {}));
