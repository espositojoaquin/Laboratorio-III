
namespace vehiculos{

    export abstract class Vehiculo{
         id:number;
         marca:string;
         modelo:string;
         precio:number;  

        constructor(id:number,marc:string,mod:string,pre:number){
          this.id = id;
          this.marca = marc;
          this.modelo = mod;
          this.precio = pre;
        }
        public getMarc():string{
          return this.marca;
      }
     } 
 }