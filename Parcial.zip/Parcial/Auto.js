var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var vehiculos;
(function (vehiculos) {
    var Auto = /** @class */ (function (_super) {
        __extends(Auto, _super);
        function Auto(id, marc, mod, pre, puerta) {
            var _this = _super.call(this, id, marc, mod, pre) || this;
            _this.puertas = puerta;
            return _this;
        }
        Auto.prototype.getMarc = function () {
            return this.marca;
        };
        Auto.prototype.getMod = function () {
            return this.modelo;
        };
        Auto.prototype.getPre = function () {
            return this.precio;
        };
        Auto.prototype.getPuer = function () {
            return this.puertas;
        };
        Auto.prototype.getId = function () {
            return this.id;
        };
        return Auto;
    }(vehiculos.Vehiculo));
    vehiculos.Auto = Auto;
})(vehiculos || (vehiculos = {}));
