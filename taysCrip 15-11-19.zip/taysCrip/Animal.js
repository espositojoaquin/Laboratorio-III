var animales;
(function (animales) {
    var Animal = /** @class */ (function () {
        function Animal() {
        }
        Animal.prototype.makeSound = function () {
            console.log("animal" + this.name);
        };
        ; //dentro de las interface lo va function; no existe en javascript no se puede trasnpirar
        return Animal;
    }());
    animales.Animal = Animal;
})(animales || (animales = {}));
