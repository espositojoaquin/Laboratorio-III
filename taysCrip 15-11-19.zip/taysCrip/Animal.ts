namespace animales{

   export abstract class Animal{
        name:string;
        makeSound(){
            console.log("animal"+ this.name);
        }; //dentro de las interface lo va function; no existe en javascript no se puede trasnpirar
       
    }
}