/*interface Animal{
    name:string;
    makeSound():void; //dentro de las interface lo va function; no existe en javascript no se puede trasnpirar
   
}
abstract class Animal{
    name:string;
    makeSound(){
        console.log("animal"+ this.name);
    }; //dentro de las interface lo va function; no existe en javascript no se puede trasnpirar
   
}
class Dog implements Animal{
    public name:string;
    constructor(name:string)
    {
        this.name=name;
    }
    makeSound(){
        console.log("Guau!!",this.name);
    }

}
class Cat implements Animal{
    public name:string;
    constructor(name:string)
    {
        this.name=name;
    }
    makeSound(){
        console.log("Mia!!",this.name);
    }

}

class cab extends Animal{   // si animal fuera una clase lo puedo heredar asi
    
    makeSound(){

        console.log("Mia!!",this.name);
    }

} */
var animales;
(function (animales) {
    function makeSound() {
        var miPerro = new animales.Dog();
        var miGato = new animales.Cat();
        //miPerro.makeSound();
        //miGato.makeSound(); 
        var lista = new Array();
        lista.push(miPerro);
        lista.push(miGato);
        lista.forEach(function (animal) {
            animal.makeSound();
        });
    }
    animales.makeSound = makeSound;
})(animales || (animales = {}));
/*
var miPerro:Dog = new Dog("Toby");
var miGato:Cat = new Cat("Michi");
//miPerro.makeSound();
//miGato.makeSound();

var lista: Array<Animal> = new Array<Animal>();

lista.push(miPerro);
lista.push(miGato);

lista.forEach(function(animal){
     animal.makeSound();
})*/
