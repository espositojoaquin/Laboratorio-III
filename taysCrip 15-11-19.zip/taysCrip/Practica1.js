// Tipos
var batman = "Bruce";
var superman = "Clark";
var existe = false;
// Tuplas
var parejaHeroes = [batman, superman];
parejaHeroes[0] = "Spidermarn";
parejaHeroes[1] = "CapitanAmerica";
var villano = ["Lex Lutor", 5, true];
villano[0] = "Guason";
villano[1] = 6;
villano[2] = false;
// Arreglos
var aliados = ["Mujer Maravilla", "Acuaman", "San", "Flash"];
//Enumeraciones 
var Fuerzas;
(function (Fuerzas) {
    Fuerzas[Fuerzas["fuerzaFlash"] = 5] = "fuerzaFlash";
    Fuerzas[Fuerzas["fuerzaSuperman"] = 100] = "fuerzaSuperman";
    Fuerzas[Fuerzas["fuerzaBatman"] = 1] = "fuerzaBatman";
    Fuerzas[Fuerzas["fuerzaAcuaman"] = 0] = "fuerzaAcuaman";
})(Fuerzas || (Fuerzas = {}));
/*var fuerzaFlash = 5;
var fuerzaSuperman = 100;
var fuerzaBatman = 1;
var fuerzaAcuaman = 0;*/
// Retorno de funciones
function activar_batiseñal() {
    return "activada";
}
function pedir_ayuda() {
    console.log("Auxilio!!!");
}
// Aserciones de Tipo: detecta el tipo que se le asigna. 
var poder = "100";
var largoDelPoder = poder.length;
console.log(largoDelPoder);
