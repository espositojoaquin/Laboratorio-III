namespace animales
{
   export class Cat extends Animal{   // si animal fuera una clase lo puedo heredar asi
        
        makeSound(){
    
            console.log("Miau!!",this.name);
        }
    
    } 

}