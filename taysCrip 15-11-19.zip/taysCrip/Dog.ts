namespace animales{
export class Dog extends Animal{   // si animal fuera una clase lo puedo heredar asi

    makeSound(){

        console.log("Gua!!",this.name);
    }

}

} 