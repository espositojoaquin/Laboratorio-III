
var flagcolum=false;
var FlagForm=false;
var filaMod;
var id;

$("document").ready(function(){
    servidor();
   // $("#agregar").click(Aniadir);
})


function hacerColumnas(objeto)
{ 
 var tCuerpo = document.getElementById("tabla");
//var objeto = JSON.parse(obj);  
var colums = Object.keys(objeto); 
for (var h = 0; h < colums.length; h++) {
    if(h<5){

        var th = document.createElement("th");
        var text = document.createTextNode(colums[h]);
        th.appendChild(text);
        tCuerpo.appendChild(th);
    }
}

}

function hacerFilas(objeto){
    var tCuerpo = document.getElementById("tabla");
    //var objeto = JSON.parse(obj);    
    var colums = Object.keys(objeto); 
    var row = document.createElement("tr");
    for(var j=0; j<colums.length; j++)
    {  if(j<5)
        {
            var cel = document.createElement("td");
            if(j==3)
            {
                var text = document.createTextNode(objeto[colums[j]].nombre);
            }
            else
            {
                var text = document.createTextNode(objeto[colums[j]]);
    
            }
            cel.appendChild(text);
            row.appendChild(cel);
            row.addEventListener('dblclick',function(){editar(event)});

        }
    }

    tCuerpo.appendChild(row);
    //limpiar();
}


//var lista={datos,date};

function hacerTabla(objeto)
{
    var tCuerpo = document.getElementById("tabla");
   // var objeto = JSON.parse([obj]);    
    for (var i = 0; i <objeto.length; i++) {  
        
        if(i==0)
        {
            hacerColumnas(objeto[i]);
        }

        hacerFilas(objeto[i]);
        
    }
} 
function HacerPopUp()
{   
  
    if( $("#formulario").is(':hidden') && FlagForm==false)
    {
       /* var salir = document.createElement("input");
        salir.type="button";
        salir.id="salir";
        salir.value="X";
        salir.addEventListener("click",divDesaparecer);
        $("#formulario").append(salir);
        var salto0 = document.createElement("br");
        $("#formulario").append(salto0);*/
        var label = document.createElement("label");
        var textoLabel1 = document.createTextNode("Nombre");
        label.appendChild(textoLabel1);
      
       $("#formulario").append(label);
        
        var input= document.createElement("input");
        input.type="text";
        input.id="nombreId";
     
        $("#formulario").append(input);
        var label2 = document.createElement("label");
        var textoLabel2 = document.createTextNode("Apellido");
        label2.appendChild(textoLabel2);
     
       $("#formulario").append(label2);
        var input2= document.createElement("input");
        input2.type="text";
        input2.id="apellidoId";
 
       $("#formulario").append(input2);
         
       var label3 = document.createElement("label");
       var textoLabel3 = document.createTextNode("Provincia");
       label3.appendChild(textoLabel3); 
       $("#formulario").append(label3);
       var prov = document.createElement("SELECT"); 
       prov.id="provincia";
       prov.addEventListener("change",cargarLocalidad);
       $("#formulario").append(prov);
       cargarProvincias();
       var sal = document.createElement("br");
       $("#formulario").append(sal);
       var lab = document.createElement("label");
       var te= document.createTextNode("Localidad");
       lab.appendChild(te);
       $("#formulario").append(te);
       var loc = document.createElement("SELECT"); 
       loc.id="localidad";
       $("#formulario").append(loc);
       var s = document.createElement("br");
     
       $("#formulario").append(s);
        var label4 = document.createElement("label");
        var textoLabel4 = document.createTextNode("Sexo");
        label4.appendChild(textoLabel4);
     
       $("#formulario").append(label4);
        var salto = document.createElement("br");
     
        $("#formulario").append(salto);
        var input4 = document.createElement("input");

        input4.type="radio";
        input4.value="Femenino";
        input4.name="gender";
        input4.id="Radioid";
  
        $("#formulario").append(input4);
        var radio1= document.createElement("label");
        var textoRadio = document.createTextNode("Femenino");
        radio1.appendChild(textoRadio);

        $("#formulario").append(radio1);
        var salto2 = document.createElement("br");

       $("#formulario").append(salto2);
        var input5 = document.createElement("input");
        input5.type="radio";
        input5.value="Masculino";
        input5.name="gender";
        input5.id="Radio2id";
     
      $("#formulario").append(input5);
        var radio2= document.createElement("label");
        var textoRadio = document.createTextNode("Masculino");
        radio2.appendChild(textoRadio);
 
      $("#formulario").append(radio2);
        var salto3 = document.createElement("br");
   
      $("#formulario").append(salto3);
      var salto4 = document.createElement("br");
      $("#formulario").append(salto4);
     
        var botonModificar= document.createElement("input");
        botonModificar.value ="Modificar";
        botonModificar.id="btnModificar";
        botonModificar.type="button";
        botonModificar.className="boton";
        botonModificar.addEventListener("click",mod)
      
       $("#formulario").append(botonModificar);
     
        FlagForm=true;
    }
    //divAparecer();
}
function cargarProvincias(){
    $.get("http://localhost:3000/provincias", function(data, status){
           
        for (var index = 0; index < data.length; index++) {
                  console.log(data[index]);
           var option =  document.createElement("option");
          //  option.id = data[index].id;
            option.value = data[index].id;
            var texto = document.createTextNode(data[index].nombre);
            option.appendChild(texto);
            $("#provincia").append(option);
         }
      });   
}
function cargarLocalidad(){
   
    var id = $( "#provincia option:selected" ).val();
    console.log(id);
    $.get("http://localhost:3000/localidades?idProv="+id, function(data, status){
           
        for (var index = 0; index < data.length; index++) {
                  console.log(data[index]);
           var option =  document.createElement("option");
            option.id = data[index].id;
            option.value = data[index].nombre;
            var texto = document.createTextNode(data[index].nombre);
            option.appendChild(texto);
            $("#localidad").append(option);
         }
      });   
}
function editar(e){
  HacerPopUp();
  $("#formulario").show();
  e.preventDefault(); 
  id=e.target.parentNode.children[0].innerHTML;
  var id = e.target.parentNode.children[0].innerHTML;
  var nombre = e.target.parentNode.children[1].innerHTML;
  var apellido = e.target.parentNode.children[2].innerHTML;
  var localidad= e.target.parentNode.children[3].innerHTML
  var sexo = e.target.parentNode.children[4].innerHTML;
  
 $("#nombreId").val(nombre);
 $("#apellidoId").val(apellido);
 $("#localidad").val(localidad);
  if(sexo=="Female"){
      document.getElementById("Radioid").checked=true;
  }
  if(sexo=="Male")
  {   document.getElementById("Radio2id").checked=true;
  }
  
  $("#formulario").show();
  //divAparecer();
  filaMod=e.target.parentNode.children;
} 
function Modificar()
{
    filaMod[1].innerHTML = $("#nombreId").val(); //document.getElementById("nombreId").value;
    filaMod[2].innerHTML = $("#apellidoId").val();  //document.getElementById("apellidoId").value;
    filaMod[3].innerHTML = $("#localidad").val();
    if($("#Radioid").is(':checked'))
    {
        filaMod[4].innerHTML = "Female";
       
    }
    if($("#Radio2id").is(':checked'))
    {   
        filaMod[4].innerHTML = "Male";
    }
   
    
}
function mod(){
    var sex;
    if($("#Radioid").is(':checked')){
        sex="Female";
    }
    else
    {
        sex="Male";
    }
    $.post("http://localhost:3000/editar",
    {
        "id": id,
        "nombre": $("#nombreId").val(),
        "apellido":$("#apellidoId").val(),
        "localidad":$("#localidad").val(),
        "sexo":sex
    },
    function(data, status){
  
     
        Modificar();
       
     
    });
    $("#formulario").hide();
}   

    function servidor()
    {
        $.get("http://localhost:3000/personas", function(data, status){
           
            hacerTabla(data);
            for (var index = 0; index < data.length; index++) {
                      
                console.log(data[index]);
               // hacerTabla(data[index]);
                
             }
          });   
    }