var nombre;
nombre = "joa";
nombre = 1231
if (nombre === "1231") {
    alert("El nombre es:1231");

} else {
    alert("No es igual");
}

function sumar(num1, num2) {

    alert(num1 + num2);
    return num1 + num2;
}

function mostrar() {
    var user = "joa";
    var password = "rojo";
    if (document.getElementById('user').value == user && document.getElementById('contra').value == password) {
        alert("Iniciando sesion...");
    } else {
        alert("Nombre de usuario o contraseña incorrecta");
    }
}
console.log(sumar(1, 2));