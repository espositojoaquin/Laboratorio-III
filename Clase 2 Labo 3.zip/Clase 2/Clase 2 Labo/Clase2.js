window.addEventListener("load",inicio);


function inicio(){
    var btnGuardar = document.getElementById("btn2");
    btnGuardar.addEventListener("click",guardar);
}
function sumar(){
    var num1= document.getElementById("num1").value;
    var num2= document.getElementById("num2").value;
    var resultado;
    resultado= parseInt(num1) + parseInt(num2);
    document.getElementById("resultado").value=resultado;

}

function guardar()
{   sumar();
    var tabla= document.getElementById("body").innerHTML +="<tr><td>"+document.getElementById("num1").value + "</td><td>" + document.getElementById("num2").value + "</td><td>"+document.getElementById("resultado").value +"</td></tr>";
}
// Funcion que reemplaza el document.getElementById() 
function $(id)
{
    var num= document.getElementById(id);
    return num;
}