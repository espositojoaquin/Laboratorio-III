window.addEventListener("load",inicio);


function inicio(){
    var btnGuardar = document.getElementById("btn2");
    btnGuardar.addEventListener("click",guardar);
}
function sumar(){
    var num1= document.getElementById("num1").value;
    var num2= document.getElementById("num2").value;
    var resultado;
    resultado= parseInt(num1) + parseInt(num2);
    document.getElementById("resultado").value=resultado;

}

function guardar()
{  // sumar();
   var bandera=seterClases();
   if(bandera==true)
   {
       var fila = document.getElementById("body").innerHTML +="<tr><td>"+document.getElementById("nombre").value + "</td><td>" + document.getElementById("Apellido").value + "</td>"+ '  <td><a href="" onclick= "borrar(event)"> Borrar </a></td>';

   }else
   {
       alert("Complete los datos faltantes");
   }
}
// Funcion que reemplaza el document.getElementById() 
function $(id)
{
    var num= document.getElementById(id);
    return num;
}
function borrar(e)
{
    e.preventDefault();
    console.log(e.target);
    console.log(e.target.parentNode);
    console.log(e);
    e.target.parentNode.parentNode.innerHTML="";
    alert("se borro una persona");
}
function seterClases()
{   
    var retorno=true;
    var nombre=document.getElementById("nombre").value;
    var apellido=document.getElementById("Apellido").value;
    if(nombre==""&&apellido=="")
    {
        document.getElementById("nombre").className="error";
        document.getElementById("Apellido").className="error";
        retorno=false;
    }
    else
    {
        document.getElementById("nombre").className="sinError";
        document.getElementById("Apellido").className="sinError";
        retorno=true;
    } 

 return retorno;

}